
CREATE DATABASE IF NOT EXISTS pwiiib
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE pwiiib;

CREATE TABLE IF NOT EXISTS endereco (
    id          INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    cep         CHAR(8)         NOT NULL,
    logradouro  VARCHAR(200)    NOT NULL DEFAULT '',
    bairro      VARCHAR(100)    NOT NULL DEFAULT '',
    cidade      VARCHAR(100)    NOT NULL DEFAULT '',
    uf          CHAR(2)         NOT NULL DEFAULT '',
    pais        VARCHAR(50)     NOT NULL DEFAULT 'Brasil',
    criado_em   TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


INSERT INTO endereco (cep, logradouro, bairro, cidade, uf, pais)  VALUES (13382482, 'Rua das Paineiras', 'Jardim da Alvorada ', 'Nova Odessa', 'SP', 'Brasil');

INSERT INTO endereco (cep, logradouro, bairro, cidade, uf, pais)  VALUES (11111111, 'Testes', 'Teste ', 'Nova Odessa', 'SP', 'Brasil');

INSERT INTO endereco (cep, logradouro, bairro, cidade, uf, pais) VALUES (01001000, 'Praça da Sé', 'Sé', 'São Paulo', 'SP', 'Brasil');

INSERT INTO endereco (cep, logradouro, bairro, cidade, uf, pais) VALUES (01310100, 'Avenida Paulista', 'Bela Vista', 'São Paulo', 'SP', 'Brasil');

INSERT INTO endereco (cep, logradouro, bairro, cidade, uf, pais) VALUES (20040030, 'Rua do Ouvidor', 'Centro', 'Rio de Janeiro', 'RJ', 'Brasil');

INSERT INTO endereco (cep, logradouro, bairro, cidade, uf, pais) VALUES (30140071, 'Rua dos Aimorés', 'Boa Viagem', 'Belo Horizonte', 'MG', 'Brasil');
