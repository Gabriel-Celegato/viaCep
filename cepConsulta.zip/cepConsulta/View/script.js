async function consultarCep() {

    if(/[^0-9-]/.test(document.getElementById('cep').value)){
        alert("VC DIGITOU UM SABOR CEP");
        return;
    }
    else if(document.getElementById('cep').value == ''){
        alert("Ta vazio meu patrão");
        return;
    }

    const cep = document.getElementById('cep').value;
    const btn = document.querySelector('button');

    btn.innerText = "Carregando...";
    btn.disabled  = true;

    try {
        const response = await fetch(`../Controller/CepAPI.php?cep=${cep}`);
        const data = await response.json();

        if (data.erro) {
            alert("CEP não encontrado!");
        } else {
            document.getElementById('logradouro').value = data.logradouro;
            document.getElementById('bairro').value     = data.bairro;
            document.getElementById('cidade').value     = data.localidade;

            // POST para salvar no banco
            await fetch('../Controller/EnderecoPost.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ cep: cep })
            });
        }
    } catch (error) {
        console.error("Erro na requisição:", error);
        alert("Erro ao consultar o servidor.");
    } finally {
        btn.innerText = "Buscar";
        btn.disabled = false;
    }
}

async function deletarCep(id) {

    try {
        // Monta o caminho base dinamicamente, sem hardcodar o domínio
        const response = await fetch(`../Controller/EnderecoApi.php?id=${id}`, {method: 'DELETE'});
        const data = await response.json();

        if (data.erro) {
            alert("CEP não encontrado!"); 
           // Recarrega a página para atualizar a lista
        } else {
          alert("Cep deletado com sucesso!");
          location.reload();
        }
    } catch (error) {
        console.error("Erro na requisição:", error);
        alert("Erro ao consultar o servidor. ");
    } 
}

async function buscarCep(cepParaBuscar){

    cepParaBuscar = cepParaBuscar.replace(/\s/g, '').replace(/-/g, '');
    if(/[^0-9-]/.test( cepParaBuscar)){

        alert("Voce digitou um sabor cep " + "O cep digitado foi: " + cepParaBuscar);
        return;
    }
else if(document.getElementById('cepParaBuscar').value == '')
{
    alert("Cep vazio, preencha-o");
    return;
}
else{
    try {
        // Monta o caminho base dinamicamente, sem hardcodar o domínio
     
        const response = await fetch(`../Controller/BuscarCep.php?cepParaBuscar=${cepParaBuscar}`);
        const data = await response.json();
        document.getElementById('resultadoBusca').innerHTML = '';

        if (data.erro) {
            alert("CEP não encontrado! Erro aqui kkkkk");
        } else {
            if (data.length === 0) {
                document.getElementById('resultadoBusca').innerHTML = 
                    `<tr><td colspan="6" style="color:#555">Nenhum resultado encontrado.</td></tr>`;
            } else {
                const endereco = data[0];
                document.getElementById('resultadoBusca').innerHTML = `
                    <tr>
                        <td>${endereco.id}</td>
                        <td>${endereco.cep}</td>
                        <td>${endereco.logradouro}</td>
                        <td>${endereco.bairro}</td>
                        <td>${endereco.cidade}</td>
                        <td>${endereco.uf}</td>
                    </tr>
                `;
            }
        }
    } catch (error) {
        console.error("Erro na requisição:", error);
        alert("Erro ao consultar o servidor.");
    }
}
}