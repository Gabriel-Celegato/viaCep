<?php
require_once '../Model/Endereco.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $body = json_decode(file_get_contents('php://input'), true);
    $cep  = $body['cep'] ?? null;

    if (!$cep) {
        echo json_encode(['erro' => 'CEP não informado']);
        exit;
    }

    $endereco = new Endereco($cep);
    $resultado = $endereco->inserir();

    if ($resultado) {
        http_response_code(201);
        echo json_encode(['sucesso' => 'Endereço salvo!']);
    } else {
        http_response_code(500);
        echo json_encode(['erro' => 'Erro ao salvar']);
    }

} else {
    echo json_encode(['erro' => 'Método não permitido']);
}